@extends('layouts.admin')
@section('admin-title', 'Testimoni')
@section('content')
<div class="bg-white rounded shadow p-8">
    <h2 class="text-xl font-bold mb-4">Daftar Testimoni</h2>
    <p>Daftar testimoni akan tampil di sini.</p>
</div>
@endsection 