
<?php $__env->startSection('admin-title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded shadow p-8 text-center max-w-xl mx-auto">
    <h2 class="text-2xl font-bold mb-4">Selamat Datang di Dashboard Admin</h2>
    <p class="text-gray-700">Gunakan menu di sebelah kiri untuk mengelola Berita, Kategori, dan Testimoni.</p>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\InternWeb\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>