
<?php $__env->startSection('admin-title', 'Testimoni'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded shadow p-8">
    <h2 class="text-xl font-bold mb-4">Daftar Testimoni</h2>
    <p>Daftar testimoni akan tampil di sini.</p>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\InternWeb\resources\views/admin/testimoni/index.blade.php ENDPATH**/ ?>