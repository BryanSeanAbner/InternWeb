

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-8">
    <h1 class="text-2xl font-bold mb-4">Bidang Magang di Nusantara TV</h1>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white rounded shadow p-4 text-center">
            <div class="text-lg font-semibold mb-2"><?php echo e($cat->name); ?></div>
            <div class="mb-2"><span style="background:<?php echo e($cat->color); ?>;padding:2px 8px;border-radius:4px;color:#fff"><?php echo e($cat->color); ?></span></div>
            <div class="text-gray-600 text-sm"><?php echo e($cat->description ?? '-'); ?></div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\InternWeb\resources\views/categories/index.blade.php ENDPATH**/ ?>