

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-8">
    <h1 class="text-2xl font-bold mb-4">Testimoni Alumni Internship Nusantara TV</h1>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white rounded shadow p-4 text-center">
            <?php if($t->getMedia('photo')->count() > 0): ?>
                <img src="<?php echo e($t->getMedia('photo')->first()->getUrl()); ?>" alt="<?php echo e($t->name); ?>" class="w-20 h-20 object-cover rounded-full mx-auto mb-2">
            <?php else: ?>
                <div class="w-20 h-20 bg-gray-200 rounded-full mx-auto mb-2 flex items-center justify-center">
                    <span class="text-gray-500 text-xs">No Photo</span>
                </div>
            <?php endif; ?>
            <div class="font-semibold mb-1"><?php echo e($t->name); ?></div>
            <div class="text-gray-600 text-sm italic">"<?php echo e($t->content); ?>"</div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\InternWeb\resources\views/testimonials/index.blade.php ENDPATH**/ ?>