

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-10">
    <div class="bg-white rounded shadow p-8 max-w-xl mx-auto">
        <h1 class="text-3xl font-bold mb-4 text-center">Selamat Datang di Halaman Admin</h1>
        <p class="mb-6 text-center text-gray-700">Silakan pilih menu di bawah untuk mengelola data website:</p>
        <ul class="space-y-4">
            <li>
                <a href="<?php echo e(route('posts.index')); ?>" class="block px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-center font-semibold">Kelola Berita Magang</a>
            </li>
            <li>
                <a href="<?php echo e(route('categories.index')); ?>" class="block px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 text-center font-semibold">Kelola Bidang Magang</a>
            </li>
            <li>
                <a href="<?php echo e(route('testimonials.index')); ?>" class="block px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700 text-center font-semibold">Kelola Testimoni Alumni</a>
            </li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\InternWeb\resources\views/admin/index.blade.php ENDPATH**/ ?>