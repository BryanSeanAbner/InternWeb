

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-6">
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-2xl font-bold">Daftar Testimoni</h2>
        <a href="<?php echo e(route('admin.testimonials.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded">Tambah Testimoni</a>
    </div>
    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white rounded shadow">
            <thead>
                <tr>
                    <th class="px-4 py-2">Nama</th>
                    <th class="px-4 py-2">Kategori</th>
                    <th class="px-4 py-2">Isi</th>
                    <th class="px-4 py-2">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border px-4 py-2"><?php echo e($t->name); ?></td>
                    <td class="border px-4 py-2"><?php echo e($t->category->name ?? '-'); ?></td>
                    <td class="border px-4 py-2"><?php echo e(Str::limit($t->description, 60)); ?></td>
                    <td class="border px-4 py-2">
                        <a href="<?php echo e(route('admin.testimonials.edit', $t)); ?>" class="text-blue-600">Edit</a>
                        <form action="<?php echo e(route('admin.testimonials.destroy', $t)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 ml-2" onclick="return confirm('Yakin hapus?')">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="mt-4"><?php echo e($testimonials->links()); ?></div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\InternWeb\resources\views/admin/testimonials/index.blade.php ENDPATH**/ ?>